﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flappy_Bird_Game
{

    public partial class Form1 : Form
    {

        int PipeSpeed = 5;
        int Gravity = 5;
        int Points = 0;

        //----------
        private byte CountDownValue ;
        private bool GameStarted = false;





        public Form1()
        {
            InitializeComponent();
        }


        private void InitializeGame()
        {
            pbPipeLookDown.Left = 800;
            pbPipeLookUp.Left = 950;
            pbFlappyBird.Top = 200;
            Points = 0;
            lblScore.Text = "Points: 0";
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {

            

            pbFlappyBird.Top += Gravity;

            pbPipeLookDown.Left -= PipeSpeed;

            pbPipeLookUp.Left -= PipeSpeed;

            lblScore.Text = "Points: " + Points;

            if (pbPipeLookDown.Left < -150)
            {
                pbPipeLookDown.Left = 800;
                Points++;
            }

            if (pbPipeLookUp.Left < -100)
            {
                pbPipeLookUp.Left = 950; 
                Points++;
            }

            if(
                pbFlappyBird.Bounds.IntersectsWith(pbPipeLookDown.Bounds)
                ||
                pbFlappyBird.Bounds.IntersectsWith(pbPipeLookUp.Bounds)
                ||
                pbFlappyBird.Bounds.IntersectsWith(pbGround.Bounds)
                ||
                pbFlappyBird.Top < -26
                )
            {

                EndGame();
            }

            UpdateGameSpeed();
        }



        private void GameKeyIsDown(object sender, KeyEventArgs e)
        {
            if (!GameStarted && e.KeyCode == Keys.Space) 
            {
                StartCountDown();
            }
            else if (e.KeyCode == Keys.Space)
            {
                Gravity = -10;
            }

        }

       
        private void GameKeyIsUp(object sender, KeyEventArgs e)
        {
          
            if(e.KeyCode==Keys.Space)
            {
                Gravity = 10;
            }
        }

        private void UpdateGameSpeed()
        {
            if (Points == 15 || Points == 55 || Points == 100 || Points == 300) 
            {
                PipeSpeed++;
            }
        }

        private void StartCountDown()
        {
            CountDownValue = 5;

            lblCounter.Text = CountDownValue.ToString();
            lblCounter.Visible = true;
            lblStartMessage.Visible = false;

            CountDownTimer.Start();
            
        }
        private void CountDownTimerEvent(object sender, EventArgs e)
        {
            CountDownValue--;

            if (CountDownValue > 0)
            {
                lblCounter.Text = CountDownValue.ToString();

            }
            else
            {
                CountDownTimer.Stop();
                StartGame();
                //MessageBox.Show("Test","Test");
            }
        }
       
       private void StartGame()
        {
            GameStarted = true;
            lblCounter.Visible = false;

            gametimer.Start();
        }


        private void EndGame()
        {
            gametimer.Stop();
            lblScore.Text += " GAME OVER!!!";

            GameStarted = false;
            InitializeGame();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // gametimer.Stop();
           //if( MessageBox.Show("Start Game? Y/N","Game",MessageBoxButtons.YesNo) == DialogResult.Yes)
           // {
           //     gametimer.Start();
           // }
           
        }

       
    }
}
