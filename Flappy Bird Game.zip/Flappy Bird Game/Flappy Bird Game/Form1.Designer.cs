﻿namespace Flappy_Bird_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblScore = new System.Windows.Forms.Label();
            this.gametimer = new System.Windows.Forms.Timer(this.components);
            this.pbGround = new System.Windows.Forms.PictureBox();
            this.pbFlappyBird = new System.Windows.Forms.PictureBox();
            this.pbPipeLookDown = new System.Windows.Forms.PictureBox();
            this.pbPipeLookUp = new System.Windows.Forms.PictureBox();
            this.lblStartMessage = new System.Windows.Forms.Label();
            this.CountDownTimer = new System.Windows.Forms.Timer(this.components);
            this.lblCounter = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbGround)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFlappyBird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPipeLookDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPipeLookUp)).BeginInit();
            this.SuspendLayout();
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.Location = new System.Drawing.Point(12, 9);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(72, 22);
            this.lblScore.TabIndex = 4;
            this.lblScore.Text = "Score:0";
            // 
            // gametimer
            // 
            this.gametimer.Interval = 20;
            this.gametimer.Tick += new System.EventHandler(this.GameTimerEvent);
            // 
            // pbGround
            // 
            this.pbGround.Image = global::Flappy_Bird_Game.Properties.Resources.ground;
            this.pbGround.Location = new System.Drawing.Point(-9, 380);
            this.pbGround.Name = "pbGround";
            this.pbGround.Size = new System.Drawing.Size(528, 95);
            this.pbGround.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbGround.TabIndex = 3;
            this.pbGround.TabStop = false;
            // 
            // pbFlappyBird
            // 
            this.pbFlappyBird.BackColor = System.Drawing.Color.Transparent;
            this.pbFlappyBird.Image = global::Flappy_Bird_Game.Properties.Resources.bird;
            this.pbFlappyBird.Location = new System.Drawing.Point(53, 88);
            this.pbFlappyBird.Name = "pbFlappyBird";
            this.pbFlappyBird.Size = new System.Drawing.Size(54, 44);
            this.pbFlappyBird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFlappyBird.TabIndex = 2;
            this.pbFlappyBird.TabStop = false;
            // 
            // pbPipeLookDown
            // 
            this.pbPipeLookDown.Image = global::Flappy_Bird_Game.Properties.Resources.pipedown;
            this.pbPipeLookDown.Location = new System.Drawing.Point(327, -5);
            this.pbPipeLookDown.Name = "pbPipeLookDown";
            this.pbPipeLookDown.Size = new System.Drawing.Size(74, 151);
            this.pbPipeLookDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPipeLookDown.TabIndex = 1;
            this.pbPipeLookDown.TabStop = false;
            // 
            // pbPipeLookUp
            // 
            this.pbPipeLookUp.Image = global::Flappy_Bird_Game.Properties.Resources.pipe;
            this.pbPipeLookUp.Location = new System.Drawing.Point(242, 272);
            this.pbPipeLookUp.Name = "pbPipeLookUp";
            this.pbPipeLookUp.Size = new System.Drawing.Size(74, 185);
            this.pbPipeLookUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPipeLookUp.TabIndex = 0;
            this.pbPipeLookUp.TabStop = false;
            // 
            // lblStartMessage
            // 
            this.lblStartMessage.AutoSize = true;
            this.lblStartMessage.BackColor = System.Drawing.Color.Transparent;
            this.lblStartMessage.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartMessage.Location = new System.Drawing.Point(150, 149);
            this.lblStartMessage.Name = "lblStartMessage";
            this.lblStartMessage.Size = new System.Drawing.Size(221, 25);
            this.lblStartMessage.TabIndex = 5;
            this.lblStartMessage.Text = "Press \'Space\' To Start!";
            // 
            // CountDownTimer
            // 
            this.CountDownTimer.Interval = 1000;
            this.CountDownTimer.Tick += new System.EventHandler(this.CountDownTimerEvent);
            // 
            // lblCounter
            // 
            this.lblCounter.AutoSize = true;
            this.lblCounter.BackColor = System.Drawing.Color.Transparent;
            this.lblCounter.Font = new System.Drawing.Font("Trebuchet MS", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCounter.Location = new System.Drawing.Point(251, 183);
            this.lblCounter.Name = "lblCounter";
            this.lblCounter.Size = new System.Drawing.Size(34, 37);
            this.lblCounter.TabIndex = 6;
            this.lblCounter.Text = "5";
            this.lblCounter.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(509, 450);
            this.Controls.Add(this.lblCounter);
            this.Controls.Add(this.lblStartMessage);
            this.Controls.Add(this.pbGround);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.pbFlappyBird);
            this.Controls.Add(this.pbPipeLookDown);
            this.Controls.Add(this.pbPipeLookUp);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GameKeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GameKeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.pbGround)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFlappyBird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPipeLookDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPipeLookUp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPipeLookUp;
        private System.Windows.Forms.PictureBox pbPipeLookDown;
        private System.Windows.Forms.PictureBox pbFlappyBird;
        private System.Windows.Forms.PictureBox pbGround;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Timer gametimer;
        private System.Windows.Forms.Label lblStartMessage;
        private System.Windows.Forms.Timer CountDownTimer;
        private System.Windows.Forms.Label lblCounter;
    }
}

