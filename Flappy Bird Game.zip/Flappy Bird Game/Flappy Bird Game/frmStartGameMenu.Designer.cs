﻿namespace Flappy_Bird_Game
{
    partial class frmStartGameMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStartGame = new System.Windows.Forms.Button();
            this.pbFlasppyBird = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGameInfo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbFlasppyBird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStartGame
            // 
            this.btnStartGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnStartGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStartGame.Location = new System.Drawing.Point(117, 226);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(143, 46);
            this.btnStartGame.TabIndex = 0;
            this.btnStartGame.Text = "Start Game";
            this.btnStartGame.UseVisualStyleBackColor = false;
            this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
            // 
            // pbFlasppyBird
            // 
            this.pbFlasppyBird.Image = global::Flappy_Bird_Game.Properties.Resources.bird;
            this.pbFlasppyBird.Location = new System.Drawing.Point(26, 39);
            this.pbFlasppyBird.Name = "pbFlasppyBird";
            this.pbFlasppyBird.Size = new System.Drawing.Size(55, 48);
            this.pbFlasppyBird.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFlasppyBird.TabIndex = 2;
            this.pbFlasppyBird.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Flappy_Bird_Game.Properties.Resources.ground;
            this.pictureBox1.Location = new System.Drawing.Point(-12, 332);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(426, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(127, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Play Game";
            // 
            // btnGameInfo
            // 
            this.btnGameInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnGameInfo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGameInfo.Location = new System.Drawing.Point(117, 143);
            this.btnGameInfo.Name = "btnGameInfo";
            this.btnGameInfo.Size = new System.Drawing.Size(143, 46);
            this.btnGameInfo.TabIndex = 5;
            this.btnGameInfo.Text = "Game Info";
            this.btnGameInfo.UseVisualStyleBackColor = false;
            this.btnGameInfo.Click += new System.EventHandler(this.btnGameInfo_Click);
            // 
            // frmStartGameMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(399, 363);
            this.Controls.Add(this.btnGameInfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pbFlasppyBird);
            this.Controls.Add(this.btnStartGame);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "frmStartGameMenu";
            this.Text = "frmStartGameMenu";
            ((System.ComponentModel.ISupportInitialize)(this.pbFlasppyBird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStartGame;
        private System.Windows.Forms.PictureBox pbFlasppyBird;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGameInfo;
    }
}